//Class name:  SoftwareProject
//Written by:  Zikomo S. Bullock
//Purpose:  Final project in Software Project Management (4663), taught by Dr. Hassan Purnaghsband at Kennesaw State University
//The purpose of this class is to hold all values pertaining to software projects.  Specifically, each software project shall hold a description,
//an owner or project manager, and team members for the project.  Each software project shall hold a list of risks associated with it, and a list of both functional
//and non-functional requirements.  The number of team members working on the project will also be recorded with each Software Project.
import java.util.ArrayList;
import java.util.Iterator;


public class SoftwareProject {
    //DEFAULT CONSTRUCTOR OF THE SOFTWAREPROJECT CLASS:
    public SoftwareProject(){
        sDescription="Description of the Software Project";
        sProjectManager="Owner or Project Manager for the project";
    }


    //CONSTRUCTOR FOR THE SOFTWAREPROJECT CLASS:
    public SoftwareProject(String description, String projectManager){
        sDescription=description;
        sProjectManager=projectManager;
    }


    //GENERIC ACCESSORS FOR THE SOFTWAREPROJECT CLASS:
    public String getsDescription() { return sDescription; }

    public String getsProjectManager() { return sProjectManager; }

    public String [] getSaTeamMembers() { return teamMembers; }

    public ArrayList<Risk> getRisks() { return risks; }

    public ArrayList<Requirement> getAlFunctionalRequirement() { return alFR; }

    public ArrayList<Requirement> getAlNonFunctionalRequirement() { return alNFR; }

    public int getiMemberCount() { return iMemberCount; }

    public double getRATime() { return RATime; }

    public double getDTime() { return DTime; }

    public double getCTime() { return CTime; }

    public double getTTime() { return TTime; }

    public double getPMTime() { return PMTime; }


    //GENERIC MUTATORS FOR THE SOFTWAREPROJECT CLASS:
    public void setsDescription(String sDescription) { this.sDescription = sDescription; }

    public void setsProjectManager(String sProjectManager) { this.sProjectManager = sProjectManager; }

    public void setSaTeamMembers(String[] teamMembers) { this.teamMembers = teamMembers; }

    public void setAlRisks(ArrayList<Risk> risks) { this.risks = risks; }

    public void setAlFunctionalRequirement(ArrayList<Requirement> alFunctionalRequirement) { this.alFR = alFunctionalRequirement; }

    public void setAlNonFunctionalRequirement(ArrayList<Requirement> alNonFunctionalRequirement) { this.alNFR = alNonFunctionalRequirement; }

    public void setiMemberCount(int iMemberCount) { this.iMemberCount = iMemberCount; }

    public void addRATime(double time) { RATime += time; }

    public void addDTime(double time) { DTime += time; }

    public void addCTime(double time) { CTime += time; }

    public void addTTime(double time) { DTime += time; }

    public void addPMTime(double time) { PMTime += time; }


    //MODIFICATION MEMBER FUNCTIONS FOR THE SOFTWAREPROJECT CLASS:
    //precondition: getiMemberCount is not 0;
    //postcondition:  Team member is added to the project
    public void addTeamMember(String member){
        if(getiMemberCount()<1000){
            teamMembers[getiMemberCount()]=member;
            iMemberCount++;
        }

        else{ System.out.println("Array Limit of Members reached."); }
    }

    //postcondition:  Retrieves the total time spent on the project
    public double getTotalTime(){
        return RATime + DTime + CTime + TTime + PMTime;
    }

    //postcondition:  A Risk is added to list of project Risks
    public void addRisk(Risk risk){ risks.add(risk); }

    //postcondition:  Adds a requirement to either functional or non-functional requirements
    public void addRequirement(Requirement rq){
        if(rq.getFunctional()==false){ alNFR.add(rq); }

        else if(rq.getFunctional()==true){ alFR.add(rq); }
    }


    //ALL MEMBER VARIABLES FOR THE SOFTWAREPROJECT CLASS:
    private String sDescription;
    private String sProjectManager;
    private int iMemberCount=0;
    private String [] teamMembers=new String[1000];
    private ArrayList<Risk> risks = new ArrayList();
    private ArrayList<Requirement> alFR = new ArrayList();                    //ArrayList of Functional Requirements
    private ArrayList<Requirement> alNFR = new ArrayList();                   //ArrayList of Non-Functional Requirements

    private double RATime = 0;
    private double DTime = 0;
    private double CTime = 0;
    private double TTime = 0;
    private double PMTime = 0;

}
